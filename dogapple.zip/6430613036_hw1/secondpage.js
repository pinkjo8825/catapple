

document.addEventListener('DOMContentLoaded', ()=> {
    const spn = document.querySelector("span");
    const list = document.querySelector("ol");
    const btn = document.getElementById("sub");
    const rd1 = document.getElementById("apple");
    const rd2 = document.getElementById("pineapple");
    const rd3 = document.getElementById("pie");
    let total = 0;
    spn.innerHTML = total;
    btn.addEventListener("click", () => {
        if (rd1.checked ==true) {
            let listItem = document.createElement("li");
            listItem.innerText = rd1.value;
            list.append(listItem);
            total +=20;
            spn.innerHTML = total;
        }
        if (rd2.checked ==true) {
            let listItem = document.createElement("li");
            listItem.innerText = rd2.value;
            list.append(listItem);
            total +=50;
            spn.innerHTML = total;
        }
        if (rd3.checked ==true) {
            let listItem = document.createElement("li");
            listItem.innerText = rd3.value;
            list.append(listItem);
            total +=10;
            spn.innerHTML = total;
        }
    })
    
})