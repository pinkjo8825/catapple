
const form = document.getElementById('sub');
const table = document.getElementById('table');
form.addEventListener('click', () =>{
    let row = table.insertRow(-1);
    
    let cell1 = row.insertCell(0);
    let cell2 = row.insertCell(1);

    cell1.innerHTML = document.getElementById('names').value;
    cell2.innerHTML = document.getElementById('breeds').value;

});



